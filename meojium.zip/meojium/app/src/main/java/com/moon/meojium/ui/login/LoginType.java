package com.moon.meojium.ui.login;

/**
 * Created by moon on 2017. 8. 22..
 */

public interface LoginType {
    String NAVER = "Naver";
    String KAKAO = "Kakao";
    String GOOGLE = "Google";
}
