package com.moon.meojium.base;

/**
 * Created by moon on 2017. 8. 12..
 */

public interface FrescoImageViewer {
    void showPicker();
}
